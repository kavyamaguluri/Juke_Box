#!/bin/bash


./gradlew clean test --no-daemon