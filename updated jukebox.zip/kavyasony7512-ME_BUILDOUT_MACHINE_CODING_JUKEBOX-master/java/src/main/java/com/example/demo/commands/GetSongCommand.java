package com.example.demo.commands;

import com.example.demo.entities.Song;
import com.example.demo.services.SongService;
import java.util.List;

public class GetSongCommand implements ICommand {
    private final SongService songService;

    public GetSongCommand(SongService songService) {
        this.songService = songService;
    }

    @Override
    public void invoke(List<String> tokens) {
        if (tokens.size() < 2) {
            System.out.println("Error: Invalid number of arguments. Usage: GET_SONG <songName>");
            return;
        }

        String songName = tokens.get(1);

        Song song = songService.getSongByName(songName);
        if (song == null) {
            System.out.println("Error: Song not found.");
            return;
        }

        System.out.println("Song: " + song);
    }
}
