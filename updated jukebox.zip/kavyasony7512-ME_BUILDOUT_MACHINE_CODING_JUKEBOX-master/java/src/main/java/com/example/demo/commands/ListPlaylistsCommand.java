package com.example.demo.commands;

import com.example.demo.services.PlaylistService;
import java.util.List;

public class ListPlaylistsCommand implements ICommand {
    private final PlaylistService playlistService;

    public ListPlaylistsCommand(PlaylistService playlistService) {
        this.playlistService = playlistService;
    }

    @Override
    public void invoke(List<String> tokens) {
        playlistService.listAllPlaylists().forEach(System.out::println);
    }
}
