package com.example.demo.commands;

import com.example.demo.services.SongService;
import com.example.demo.entities.Song;
import java.util.List;

public class ListSongsCommand implements ICommand {
    private final SongService songService;

    public ListSongsCommand(SongService songService) {
        this.songService = songService;
    }

    @Override
    public void invoke(List<String> tokens) {
        List<Song> songs = songService.listAllSongs();

        if (songs.isEmpty()) {
            System.out.println("No songs available.");
            return;
        }

        StringBuilder output = new StringBuilder("[");
        for (int i = 0; i < songs.size(); i++) {
            Song song = songs.get(i);
            output.append("Song [id=").append(song.getSongId()).append("]");
            if (i < songs.size() - 1) {
                output.append(", ");
            }
        }
        output.append("]");
        System.out.println(output.toString());
    }
}


