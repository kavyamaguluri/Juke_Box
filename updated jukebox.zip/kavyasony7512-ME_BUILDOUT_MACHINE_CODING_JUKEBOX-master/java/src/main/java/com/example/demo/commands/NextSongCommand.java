package com.example.demo.commands;

import com.example.demo.services.SongService;
import com.example.demo.entities.Song;
import java.util.List;

public class NextSongCommand implements ICommand {
    private final SongService songService;

    public NextSongCommand(SongService songService) {
        this.songService = songService;
    }

    @Override
    public void invoke(List<String> tokens) {
        try {
            Song nextSong = songService.nextSong(); // Get the next song
            System.out.println("Next song is: " + nextSong.getName());
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }
    }
}


