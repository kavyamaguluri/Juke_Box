package com.example.demo.commands;

import com.example.demo.services.SongService;
import com.example.demo.entities.Song;
import java.util.List;

public class PreviousSongCommand implements ICommand {
    private final SongService songService;

    public PreviousSongCommand(SongService songService) {
        this.songService = songService;
    }

    @Override
    public void invoke(List<String> tokens) {
        try {
            Song previousSong = songService.previousSong(); // Get the previous song
            System.out.println("Previous song is: " + previousSong.getName());
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }
    }
}



