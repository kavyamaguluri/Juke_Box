package com.example.demo.commands;

import com.example.demo.services.SongService;
import java.util.List;

public class StopSongCommand implements ICommand {
    private final SongService songService;

    public StopSongCommand(SongService songService) {
        this.songService = songService;
    }

    @Override
    public void invoke(List<String> tokens) {
        try {
            // Check if a song is currently playing
            if (songService.isSongPlaying()) {
                songService.stopSong();
                System.out.println("Song stopped.");
            } else {
                System.out.println("No song is currently playing to stop.");
            }
        } catch (RuntimeException e) {
            System.out.println("Error executing command: " + e.getMessage());
        }
    }
}


