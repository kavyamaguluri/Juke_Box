package com.example.demo.repositories;

import com.example.demo.entities.Playlist;
import java.util.List;
import java.util.Optional;

public interface IPlaylistRepository {
    void save(Playlist playlist);
    Optional<Playlist> findByName(String playlistName);
    boolean exists(String name);
    void deleteByName(String name);
    List<Playlist> findAll();
}
