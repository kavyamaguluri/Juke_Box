package com.example.demo.repositories;

import com.example.demo.entities.Song;
import java.util.List;
import java.util.Optional;

public interface ISongRepository {
    void save(Song song); // Save a song to the repository

    Optional<Song> findById(int id); // Find a song by ID

    Optional<Song> findByName(String name); // Find a song by name

    List<Song> findAll(); // Retrieve all songs

    void deleteById(int id); // Delete a song by ID

    void deleteAll(); // Delete all songs
}


