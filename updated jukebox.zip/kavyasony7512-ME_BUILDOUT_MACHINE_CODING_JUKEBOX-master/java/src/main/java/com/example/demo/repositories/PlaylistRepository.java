package com.example.demo.repositories;

import com.example.demo.entities.Playlist;
import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PlaylistRepository implements IPlaylistRepository {
    private final Map<String, Playlist> playlists = new HashMap<>();

    @Override
    public void save(Playlist playlist) {
        if (playlist == null || playlist.getName() == null) {
            throw new IllegalArgumentException("Playlist or its name cannot be null");
        }
        playlists.put(playlist.getName(), playlist);
    }

    @Override
    public Optional<Playlist> findByName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Playlist name cannot be null");
        }
        return Optional.ofNullable(playlists.get(name));
    }

    @Override
    public void deleteByName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Playlist name cannot be null");
        }
        playlists.remove(name);
    }

    @Override
    public boolean exists(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Playlist name cannot be null");
        }
        return playlists.containsKey(name);
    }

    @Override
    public List<Playlist> findAll() {
        return new ArrayList<>(playlists.values());
    }
}

