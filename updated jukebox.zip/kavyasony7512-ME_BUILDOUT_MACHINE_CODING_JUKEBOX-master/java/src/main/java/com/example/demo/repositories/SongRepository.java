package com.example.demo.repositories;

import com.example.demo.entities.Song;
import java.util.*;

public class SongRepository implements ISongRepository {
    private final Map<Integer, Song> songMap = new HashMap<>();

    @Override
    public void save(Song song) {
        if (song == null) {
            throw new IllegalArgumentException("Song cannot be null");
        }
        songMap.put(song.getSongId(), song);
    }

    @Override
    public Optional<Song> findById(int id) {
        return Optional.ofNullable(songMap.get(id));
    }

    @Override
    public Optional<Song> findByName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Song name cannot be null");
        }
        return songMap.values().stream()
                .filter(s -> s.getName().equals(name))
                .findFirst();
    }

    @Override
    public List<Song> findAll() {
        return new ArrayList<>(songMap.values());
    }

    @Override
    public void deleteById(int id) {
        songMap.remove(id);
    }

    @Override
    public void deleteAll() {
        songMap.clear();
    }
}
