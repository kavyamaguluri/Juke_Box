package com.example.demo.services;

import com.example.demo.entities.Playlist;
import com.example.demo.entities.Song;
import com.example.demo.repositories.IPlaylistRepository;
import com.example.demo.repositories.ISongRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PlaylistService {
    private final ISongRepository songRepository;
    private final IPlaylistRepository playlistRepository;

    public PlaylistService(ISongRepository songRepository, IPlaylistRepository playlistRepository) {
        this.songRepository = songRepository;
        this.playlistRepository = playlistRepository;
    }

    public void executeCreatePlaylistCommand(String command) {
        // Split the command string by spaces
        String[] tokens = command.split(" ");

        // Extract the playlist name (2nd token)
        String playlistName = tokens[1];

        // Extract song IDs from the remaining tokens (starting from the 3rd token)
        List<Integer> songIds = new ArrayList<>();
        for (int i = 2; i < tokens.length; i++) {
            songIds.add(Integer.parseInt(tokens[i]));
        }

        // Create the playlist with the given name and song IDs
        createPlaylist(playlistName, songIds);
    }

    public Playlist createPlaylist(String playlistName, List<Integer> songIds) {
        // Initialize a new playlist with the provided name
        Playlist playlist = new Playlist(playlistName);

        // Fetch songs from the SongRepository and add them to the playlist
        for (Integer songId : songIds) {
            Optional<Song> songOpt = songRepository.findById(songId);
            if (songOpt.isPresent()) {
                playlist.addSong(songOpt.get());
            } else {
                System.out.println("Song with ID " + songId + " not found.");
            }
        }

        // Save the playlist in the PlaylistRepository
        playlistRepository.save(playlist);

        // Return the created playlist
        return playlist;
    }

    public void addSongToPlaylist(String playlistName, Song song) {
        Optional<Playlist> optionalPlaylist = playlistRepository.findByName(playlistName);
        if (optionalPlaylist.isPresent()) {
            Playlist playlist = optionalPlaylist.get();
            playlist.addSong(song);  // Add song to the playlist
            playlistRepository.save(playlist);  // Update the repository with the new playlist
        } else {
            throw new RuntimeException("Playlist not found");
        }
    }

    public List<Song> getSongsInPlaylist(String playlistName) {
        Playlist playlist = loadPlaylist(playlistName);
        return playlist.getSongs();  // Assuming getSongs() returns the list of songs
    }

    // Load a playlist by name
    public Playlist loadPlaylist(String playlistName) {
        if (playlistName == null || playlistName.isEmpty()) {
            throw new IllegalArgumentException("Playlist name cannot be null or empty");
        }

        return playlistRepository.findByName(playlistName)
                .orElseThrow(() -> new RuntimeException("Playlist not found: " + playlistName));
    }

    
    

    // Delete a playlist by name
    public void deletePlaylist(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Playlist name cannot be null or empty");
        }

        if (!playlistRepository.exists(name)) {
            throw new RuntimeException("Playlist not found: " + name);
        }

        playlistRepository.deleteByName(name);
    }

    // List all playlists
    public List<Playlist> listAllPlaylists() {
        return playlistRepository.findAll();
    }

    // Play the next song in the playlist
    public void nextSong(String playlistName) {
        if (playlistName == null || playlistName.isEmpty()) {
            throw new IllegalArgumentException("Playlist name cannot be null or empty");
        }

        Playlist playlist = playlistRepository.findByName(playlistName)
                .orElseThrow(() -> new RuntimeException("Playlist not found: " + playlistName));

        playlist.nextSong();  // Ensure the nextSong method is implemented in Playlist class
        playlistRepository.save(playlist);
    }

    // Play the previous song in the playlist
    public void previousSong(String playlistName) {
        if (playlistName == null || playlistName.isEmpty()) {
            throw new IllegalArgumentException("Playlist name cannot be null or empty");
        }

        Playlist playlist = playlistRepository.findByName(playlistName)
                .orElseThrow(() -> new RuntimeException("Playlist not found: " + playlistName));

        playlist.previousSong();  // Ensure the previousSong method is implemented in Playlist class
        playlistRepository.save(playlist);
    }

    //getting song as song object
    // public void removeSongFromPlaylist(String playlistName, Song song) {
    //     Playlist playlist = loadPlaylist(playlistName);
    //     playlist.removeSong(song);  // Remove the song from the playlist
    //     playlistRepository.save(playlist);  // Save the updated playlist
    //     System.out.println("Playlist " + playlistName + " is revised with " + playlist.getSongs());
    // }
    
    public void removeSongFromPlaylist(String playlistName, int songId) {
        Playlist playlist = playlistRepository.findByName(playlistName)
                .orElseThrow(() -> new RuntimeException("Playlist not found: " + playlistName));
    
        Optional<Song> songToRemove = playlist.getSongs().stream()
                .filter(song -> song.getSongId() == songId)
                .findFirst();
    
        songToRemove.ifPresent(song -> {
            playlist.removeSong(song);
            playlistRepository.save(playlist);
        });
    }
}

