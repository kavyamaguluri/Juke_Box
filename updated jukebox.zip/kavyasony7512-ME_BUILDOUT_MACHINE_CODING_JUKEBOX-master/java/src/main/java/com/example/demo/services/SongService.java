package com.example.demo.services;

import com.example.demo.entities.Song;
import com.example.demo.repositories.ISongRepository;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class SongService {
    private final ISongRepository songRepository;
    private Song currentlyPlayingSong;
    // private final List<Song> songQueue;
    private int currentIndex;
    private  List<Song> songQueue = new LinkedList<>();
    
    // Constructor
    public SongService(ISongRepository songRepository) {
        this.songRepository = songRepository;
        this.songQueue = new LinkedList<>();
        this.currentlyPlayingSong = null;
        this.currentIndex = -1;  // Initialize to -1 to indicate no song is playing
    }

    // Add a song to the repository
    public Song addSong(String name, String artist, String album, String genre) {
        Song song = new Song(name, artist, album, genre);
        songRepository.save(song);  // Save the song in the repository
        return song;
    }

    // List all songs in the repository
    public List<Song> listAllSongs() {
        return songRepository.findAll();  // Fetch all songs from the repository
    }

    // Find a song by its ID
    public Optional<Song> getSongById(int id) {
        return songRepository.findById(id);
    }

    // Get song by its name
    public Song getSongByName(String songName) {
        return songRepository.findByName(songName)
                .orElseThrow(() -> new RuntimeException("Song not found: " + songName));
    }

    // Add a song to the queue and set it as the currently playing song
    public void playSong(String songName) {
        Song song = getSongByName(songName);  // Find the song by name
        currentlyPlayingSong = song;
        // songQueue.clear();  // Clear the queue to start fresh
        songQueue.add(currentlyPlayingSong);  // Add the song to the queue
        currentIndex = songQueue.indexOf(currentlyPlayingSong);  // Set the index to the first song
        System.out.println("Song [id=" + song.getSongId() + "] is playing!");
    }

    // Play a song by its ID
    public void playSongById(int songId) {
        // Get the song by ID and handle Optional properly
        Song song = getSongById(songId)
                .orElseThrow(() -> new RuntimeException("Song not found: " + songId));  // Correct usage of orElseThrow

        currentlyPlayingSong = song;
        songQueue.clear();  // Clear the queue to start fresh
        songQueue.add(currentlyPlayingSong);  // Add the song to the queue
        currentIndex = 0;  // Set the index to the first song
        System.out.println("Song [id=" + song.getSongId() + "] is playing!");
    }

    // Stop the currently playing song
    public void stopSong() {
        if (currentlyPlayingSong != null) {
            System.out.println("Stopping song: " + currentlyPlayingSong.getName());
            currentlyPlayingSong = null;  // Clear the currently playing song
            currentIndex = -1;  // Reset the index
        } else {
            throw new RuntimeException("No song is currently playing.");
        }
    }

    // Clear the song queue
    public void clearQueue() {
        songQueue.clear();
    }

    // Add a song to the queue
    public void addToQueue(Song song) {
        songQueue.add(song);
    }

    // Get the current song queue
    public List<Song> getSongQueue() {
        return new LinkedList<>(songQueue);
    }

    // Check if a song is currently playing
    public boolean isSongPlaying() {
        return currentlyPlayingSong != null;
    }

    public Song nextSong() {
        if (songQueue.isEmpty()) {
            throw new RuntimeException("No songs in the queue.");
        }

        // Move to the next song in the queue, wrap around if necessary
        currentIndex = (currentIndex + 1) % songQueue.size();
        currentlyPlayingSong = songQueue.get(currentIndex);
        System.out.println("Playing next song: " + currentlyPlayingSong.getName());
        return currentlyPlayingSong;
    }

    // Play the previous song in the queue
    public Song previousSong() {
        if (songQueue.isEmpty()) {
            throw new RuntimeException("No songs in the queue.");
        }

        // Move to the previous song in the queue, wrap around if necessary
        currentIndex = (currentIndex - 1 + songQueue.size()) % songQueue.size();
        currentlyPlayingSong = songQueue.get(currentIndex);
        System.out.println("Playing previous song: " + currentlyPlayingSong.getName());
        return currentlyPlayingSong;
    }

    public void executePlaySongCommand(String command) {
        if (command.equals("PLAY_SONG")) {
            Song songToPlay = songQueue.isEmpty() ? null : songQueue.get(currentIndex);
            if (songToPlay != null) {
                playSong(songToPlay.getName());
            } else {
                System.out.println("No song to play.");
            }
        }
    }

    public void playNextSong() {
        if (songQueue.isEmpty()) {
            throw new RuntimeException("No songs in the queue.");
        }
        currentIndex = (currentIndex + 1) % songQueue.size();
        currentlyPlayingSong = songQueue.get(currentIndex);
        System.out.println("Playing next song: " + currentlyPlayingSong.getName());
    }
    
    public void createSong(String name, String artist, String album, String genre) {
        // Check for null or empty values
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Song name cannot be null or empty");
        }
        if (artist == null || artist.trim().isEmpty()) {
            throw new IllegalArgumentException("Artist name cannot be null or empty");
        }
        if (album == null || album.trim().isEmpty()) {
            throw new IllegalArgumentException("Album name cannot be null or empty");
        }
        if (genre == null || genre.trim().isEmpty()) {
            throw new IllegalArgumentException("Genre cannot be null or empty");
        }

        // Create a new Song entity
        Song newSong = new Song();
        newSong.setName(name);
        newSong.setArtist(artist);
        newSong.setAlbum(album);
        newSong.setGenre(genre);

        // Save the song to the repository
        songRepository.save(newSong);
    }
}
