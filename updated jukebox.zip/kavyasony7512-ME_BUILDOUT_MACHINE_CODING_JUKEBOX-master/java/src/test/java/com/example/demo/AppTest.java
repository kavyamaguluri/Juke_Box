package com.example.demo;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.util.List;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.github.stefanbirkner.systemlambda.SystemLambda.tapSystemOut;

@DisplayName("App Test")

public class AppTest {

    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @Test
    public void Application_Test() throws Exception {
        // Arrange
        Path inputFile = Paths.get("src", "test", "resources", "test_input_one.txt");
        List<String> arguments = new ArrayList<>(List.of("INPUT_FILE=" + inputFile.toString()));
        Path actualOutputFile = Paths.get("src", "test", "resources", "test_input_one_actual_output.txt");
        Path expectedOutputFile = Paths.get("src", "test", "resources", "test_input_one_expected_output.txt");
    
        // Act
        String actualOutput = tapSystemOut(() -> App.run(arguments));
        Files.writeString(actualOutputFile, actualOutput, StandardCharsets.UTF_8);
    
        // Debugging: Print contents of the files
        System.out.println("Actual Output:");
        Files.lines(actualOutputFile).forEach(System.out::println);
    
        System.out.println("Expected Output:");
        Files.lines(expectedOutputFile).forEach(System.out::println);
    
        // Assert
        Assertions.assertTrue(compareByMemoryMappedFiles(expectedOutputFile, actualOutputFile),
                "The actual output does not match the expected output.");
    }
    

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }

    // Compare files using memory-mapped files
    private boolean compareByMemoryMappedFiles(Path path1, Path path2) {
        try (var randomAccessFile1 = new RandomAccessFile(path1.toFile(), "r");
             var randomAccessFile2 = new RandomAccessFile(path2.toFile(), "r");
             var ch1 = randomAccessFile1.getChannel();
             var ch2 = randomAccessFile2.getChannel()) {

            if (ch1.size() != ch2.size()) {
                return false;
            }
            long size = ch1.size();
            var m1 = ch1.map(FileChannel.MapMode.READ_ONLY, 0L, size);
            var m2 = ch2.map(FileChannel.MapMode.READ_ONLY, 0L, size);

            return m1.equals(m2);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

